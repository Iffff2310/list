export default {
    blue: '#3498DB',
    greyLight: '#f7f7f7',
    grey: '#D8D8D8',
    geryDark:'#BBBBBB',
    black:'#000000'
}